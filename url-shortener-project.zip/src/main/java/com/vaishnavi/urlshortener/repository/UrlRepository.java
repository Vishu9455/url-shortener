package com.vaishnavi.urlshortener.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vaishnavi.urlshortener.model.Url;

public interface UrlRepository extends JpaRepository<Url, Long> {
    Url findByShortUrl(String shortUrl);
}
