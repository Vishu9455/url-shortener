package com.vaishnavi.urlshortener.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.UUID;
import com.vaishnavi.urlshortener.model.Url;
import com.vaishnavi.urlshortener.repository.UrlRepository;

@Service
public class UrlService {

    @Autowired
    private UrlRepository repo;

    public String shortenUrl(String originalUrl) {
        String shortUrl = UUID.randomUUID().toString().substring(0, 6);

        Url url = new Url();
        url.setOriginalUrl(originalUrl);
        url.setShortUrl(shortUrl);

        repo.save(url);
        return shortUrl;
    }

    public String getOriginalUrl(String shortUrl) {
        Url url = repo.findByShortUrl(shortUrl);
        url.setClickCount(url.getClickCount() + 1);
        repo.save(url);
        return url.getOriginalUrl();
    }
}
